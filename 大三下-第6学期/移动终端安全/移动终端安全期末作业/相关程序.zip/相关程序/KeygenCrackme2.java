import java.math.BigInteger;
import java.security.MessageDigest;

/**
 * crackme2.apk 注册机
 * 包名: com.lohan.crackme0a
 * 算法: MD5(IMEI) -> 相邻字节 XOR -> hex -> 前15位
 */
public class KeygenCrackme2 {

    public static String generateSerial(String imei) throws Exception {
        // 1. 计算 IMEI 的 MD5
        MessageDigest md = MessageDigest.getInstance("MD5");
        md.update(imei.getBytes(), 0, imei.length());
        byte[] digest = md.digest();

        // 2. Pair-XOR 变换: digest[i] ^ digest[i+1]
        //    最后一位如果落单则 XOR 0
        byte[] transform = new byte[digest.length];
        int tPos = 0;
        for (int dPos = 0; dPos < digest.length; dPos += 2) {
            int nextPos = (dPos == digest.length - 1) ? 0 : dPos + 1;
            transform[tPos] = (byte) (digest[dPos] ^ digest[nextPos]);
            tPos++;
        }

        // 3. 转十六进制字符串
        String hex = new BigInteger(1, transform).toString(16);

        // 4. 取前 15 位
        return hex.substring(0, 15);
    }

    public static void main(String[] args) throws Exception {
        // 测试模拟器默认 IMEI
        String imei1 = "358240051111110";
        System.out.println("IMEI:  " + imei1);
        System.out.println("Serial: " + generateSerial(imei1));

        System.out.println();

        // 测试模拟器特征 IMEI
        String imei2 = "000000000000000";
        System.out.println("IMEI:  " + imei2);
        System.out.println("Serial: " + generateSerial(imei2));

        if (args.length > 0) {
            System.out.println();
            System.out.println("IMEI:  " + args[0]);
            System.out.println("Serial: " + generateSerial(args[0]));
        }
    }
}
