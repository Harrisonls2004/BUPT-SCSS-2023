import java.util.Arrays;

/** Class to keep track of client (Pet) information for a Veterinary
    practice. Some methods are sketched for you, but others will need
    to be added in order to implement the Database interface and
    support the P3main program and expected output. You'll also need
    to add the data members.
*/
public class Vet implements Database {


   /** Create a veterinary practice.
    * @param startSize the capacity for how
    * many clients they can handle
    * @param who the name of the vet practice
    */
   public Vet(int startSize, String who) {
   
   }

    /** Display the name of the Vet and all the clients, one per line,
     * on the screen. (See sample output for exact format.)
    */
   public void display() {
   
   }


    /** Add an item to the database, if there is room.
        You are limited by the initial capacity.
        @param o the object to add (must be a Pet)
        @return true if added, false otherwise
    */
   public boolean add(Object o) {
   
   }

    /** Delete an item from the database, if it is there,
        maintaining the current ordering of the list.
        @param o the object to delete
        @return the item if one is deleted, null otherwise
    */
   public Object delete(Object o) {
   
   }

    /** Compute the average weight over all clients.
        @return the average
    */
   public double averageWeight() {
   
   }

    /** Sort the clients. (This is complete.)
     */
   public void sort() {
       Arrays.sort(this.clients, 0, this.size());
   }

}
